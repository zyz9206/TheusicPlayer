package com.example.myapplication.data


data class PlayListData(
// 歌单名字
    val name: String,
    // 歌单图片
    val picUrl: String,

    val playCount:Long
    // 内含歌曲
//    val songs: ArrayList<StandardSongData>
)
