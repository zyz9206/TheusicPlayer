package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.data.Myapplication
import com.example.myapplication.data.gequ
import com.example.myapplication.data.response
import com.example.myapplication.databinding.ActivityMain2Binding
import okhttp3.OkHttpClient
import okhttp3.Request
import com.google.gson.Gson
import kotlin.concurrent.thread
private val idlist= ArrayList<Int>()
class MainActivity2 : AppCompatActivity(),View.OnClickListener {
    private lateinit var binding: ActivityMain2Binding
    private lateinit var RecyclerView: RecyclerView
    private val gequlist= ArrayList<gequ>()
    private fun refresh(){
        thread{
            val request=
                Request.Builder().url("http://music.eleuu.com/simi/song?id="+(347231 until 347250).random())
                    .build()
            val rresponse= OkHttpClient().newCall(request).execute()
            val json=rresponse.body()?.string()
            binding.textView.setText(json)
            val response=Gson().fromJson(json, response::class.java)
            if(response!=null){
                val data=response.songs
                gequlist.clear()
                gequlist.addAll(data)
                runOnUiThread{
                    RecyclerView.adapter?.notifyDataSetChanged()
                }
            }
        }

    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMain2Binding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        RecyclerView=findViewById(R.id.gequ) as RecyclerView
        RecyclerView.layoutManager= LinearLayoutManager(this)
        RecyclerView.adapter=Myadapter(gequlist)
        binding.tx1.setOnClickListener {
                        val intent= Intent(it.context,MainActivity::class.java)
            it.context.startActivity(intent)
        }
        refresh()
    }

    override fun onClick(p0: View?) {
        TODO("Not yet implemented")
    }

}
class Myadapter(private val gequlist:List<gequ>): RecyclerView.Adapter<Myadapter.MyViewHolder>() {
    inner class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val title: TextView =itemView.findViewById(R.id.tx)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView= LayoutInflater.from(parent.context).inflate(R.layout.gequliebiao,parent,false)
        return MyViewHolder(itemView)
    }
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val gequ=gequlist[position]
        holder.title.text=gequ.name
        idlist.add(gequ.privilege.id)

//        holder.tx1.setOnClickListener {
//            val intent= Intent(it.context,MainActivity::class.java)
//            it.context.startActivity(intent)
//        }
    }
    override fun getItemCount(): Int {
        return gequlist.size
    }
}