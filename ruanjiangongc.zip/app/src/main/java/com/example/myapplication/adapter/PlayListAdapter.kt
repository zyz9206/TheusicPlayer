package com.example.myapplication.adapter

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.myapplication.MainActivity2
import com.example.myapplication.R
import com.example.myapplication.data.PlayListData
import com.nostra13.universalimageloader.core.ImageLoader
import com.nostra13.universalimageloader.core.assist.ImageSize
import kotlinx.coroutines.newSingleThreadContext

class PlayListAdapter(val context: Context, val PlayList:List<PlayListData>)
:RecyclerView.Adapter<PlayListAdapter.ViewHolder>() {
    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val clPlaylist: ConstraintLayout = view.findViewById(R.id.clPlaylist)
        val ivCover: ImageView = view.findViewById(R.id.ivCover)
        val tvTitle: TextView =view.findViewById(R.id.tvTitle)
        val tvSub: TextView = view.findViewById(R.id.tvSub)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context)
            .inflate(R.layout.recycler_my_playlist, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        if (position == 0 || position == 1) {
            val layoutParams = ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.MATCH_PARENT)
            layoutParams.setMargins(dp2px(10f).toInt(), 0, 0, 0)
            holder.clPlaylist.layoutParams = layoutParams
        } else if (position == PlayList.lastIndex
            || position == PlayList.lastIndex - 1) {
            val layoutParams = ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.MATCH_PARENT)
            layoutParams.setMargins(0, 0, 10.dp(), 0)
            holder.clPlaylist.layoutParams = layoutParams
        } else {
            val layoutParams = ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ConstraintLayout.LayoutParams.MATCH_PARENT)
            layoutParams.setMargins(0, 0, 0, 0)
            holder.clPlaylist.layoutParams = layoutParams
        }

        val List = PlayList[position]
 //       val mImageSize = ImageSize(100, 100)
//        ImageLoader.getInstance().loadImage(List.picUrl, mImageSize, new Si
//                mpleImageLoadingListener(){
//                    @Override
//                    public void onLoadingComplete(String imageUri, View view,
//                        Bitmap loadedImage) {
//                        super.onLoadingComplete(imageUri, view, loadedImage);
//                        ivCover.setImageBitmap(loadedImage);
//                    }
//                });

                holder.tvTitle.text=List.name
        holder.tvSub.text=when(List.playCount){
            in 1 until 10_000 -> List.playCount.toString()
            in 10_000 until 10_000_000 ->"${List.playCount/10000}万播放"
            else -> "${List.playCount / 100_000_000} 亿播放"
        }
        Glide.with(context).load(List.picUrl).centerCrop().into(holder.ivCover)
        holder.clPlaylist.setOnClickListener{
                val intent=Intent(it.context,MainActivity2::class.java)
            it.context.startActivity(intent)
        }

    }
    fun dp2px(dp: Float): Float=dp*context.resources.displayMetrics.density
    fun Int.dp(): Int {
        return dp2px(this.toFloat()).toInt()
    }


    override fun getItemCount() = PlayList.size
}