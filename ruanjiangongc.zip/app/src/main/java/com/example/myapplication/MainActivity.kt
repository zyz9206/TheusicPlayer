package com.example.myapplication

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.view.LayoutInflater
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import com.bumptech.glide.Glide
import com.example.myapplication.adapter.PlayListAdapter
import com.example.myapplication.data.PlayListData
import com.example.myapplication.data.Sentence
import com.example.myapplication.databinding.ActivityMainBinding
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList
import kotlin.concurrent.thread


class MainActivity : AppCompatActivity(), View.OnClickListener {
    private lateinit var binding: ActivityMainBinding
    val Songlist=ArrayList<PlayListData>()
    val Sentencelist=ArrayList<Sentence>()
    var num=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
//        Startthread()
        sendRequestWithHttpURLConnection()

binding.includefoyou.root.setOnClickListener {
    getSentence()
}
       binding.PlayList.layoutManager = GridLayoutManager(this, 2, GridLayoutManager.HORIZONTAL, false)
        binding.PlayList.adapter=PlayListAdapter(this, Songlist)

}
    private fun  sendRequestWithHttpURLConnection(){
        thread{
            var connection : HttpURLConnection? =null
            try{

//                val msg=Message()
//                msg.what=0
//            handler.handleMessage(msg)


//                val limit=1
//            val url = URL("http://music.eleuu.com/personalized?limit=1")
//            connection = url.openConnection() as HttpURLConnection
//            connection.requestMethod = "GET"
//
//            connection.setConnectTimeout(8000);
//            connection.setReadTimeout(8000);
//            val responseData=connection.inputStream
                val client = OkHttpClient()
                val request = Request.Builder()
                    .url("http://music.eleuu.com/personalized?limit=16")
                    .build()

                val response = client.newCall(request).execute()
                val responseData = response.body()?.string()
                val j=JSONObject(responseData)
                val p=j.getString("result")
                val n=JSONArray(p)



//                val result1=JSONArray(result)
//
//                val result2=result1.getJSONObject(0)
//                val pi=result2.getString("picUrl")


                for(i in 0 until n.length()){

                    val jsonObject1 = n.getJSONObject(i)
                    val pic = jsonObject1.getString("picUrl")
                    val name2=jsonObject1.getString("name")
                    val playCount=jsonObject1.getString("playCount")
                    val song=PlayListData(name2,pic,playCount.toLong())
                    Songlist.add(song)
                }

                val client1 = OkHttpClient()
                val request1 = Request.Builder()
                    .url("https://v1.hitokoto.cn/?encode=json")
                    .build()

                val response1 = client1.newCall(request1).execute()
                val responseData1 = response1.body()?.string()
                val hitokotoData = JSONObject(responseData1)

                val mainStr: String = hitokotoData.getString("hitokoto")
                val fromWhoStr: String = hitokotoData.getString("from_who")
                val fromStr: String = hitokotoData.getString("from")
                val Sentence1=Sentence(mainStr,fromWhoStr,fromStr)
                Sentencelist.add(Sentence1)



//                val jsonObject= JSONObject(responseData)
//
//                val result=jsonObject.getString("result")
//
//                val hh= JSONArray(result)
//
//                val picurl=hh.getJSONObject(0)
//                val p=picurl.getString("picUrl")
//                val name1=picurl.getString("name")
//                val song=PlayListData(name1,p)
//                Songlist.add(song)


//            val picurl=JSONObject(result)
//            Songlist.add(song)
                //       Glide.with(this).load(p).into(binding.imageButton)
//            val picUrl=result.getString("picUrl")

                showResponse(Songlist)
                changeSentence()
            }catch (e: Exception){
                e.printStackTrace()
            }finally {

                connection?.disconnect()
            }

        }

    }
    private fun showResponse(response: ArrayList<PlayListData>) {
        runOnUiThread {
            // 在这里进行UI操作，将结果显示到界面上
            binding.PlayList.adapter=PlayListAdapter(this, response)
//            binding.textView.setText(Songlist[0].name)
//            Glide.with(this).load(response).into(binding.imageButton)
        }
    }
    private fun getSentence(){
        thread {
            var connection : HttpURLConnection? =null
            try {
                val client1 = OkHttpClient()
                val request1 = Request.Builder()
                    .url("https://v1.hitokoto.cn/?encode=json")
                    .build()

                val response1 = client1.newCall(request1).execute()
                val responseData1 = response1.body()?.string()
                val hitokotoData = JSONObject(responseData1)

                val mainStr: String = hitokotoData.getString("hitokoto")
                val fromWhoStr: String = hitokotoData.getString("from_who")
                val fromStr: String = hitokotoData.getString("from")
                val Sentence1=Sentence(mainStr,fromWhoStr,fromStr)
                Sentencelist.add(Sentence1)
                num=num+1
                changeSentence()
            }catch (e:Exception){
                e.printStackTrace()
            }finally {
                connection?.disconnect()
            }
        }
    }
    private fun changeSentence(){
        binding.includefoyou.tvText.alpha=0f
        binding.includefoyou.tvAuthor.alpha = 0f
        binding.includefoyou.tvSource.alpha = 0f
        runOnUiThread  {
            binding.includefoyou.tvText.text = Sentencelist[num].hitokoto
            binding.includefoyou.tvAuthor.text = Sentencelist[num].author
            binding.includefoyou.tvSource.text = Sentencelist[num].source
            fadeIn(binding.includefoyou.tvText, 1000, false)
           fadeIn(binding.includefoyou.tvAuthor, 1000, false)
           fadeIn(binding.includefoyou.tvSource, 1000, false)
        }
    }

    fun fadeIn(view: View, duration: Int, smooth: Boolean) {
        if (view.visibility == View.GONE) {
            view.visibility = View.VISIBLE
        }
        val startAlpha = if (smooth) {
            view.alpha
        } else {
            0f
        }
        val objectAnimator: ObjectAnimator = ObjectAnimator.ofFloat(view, "alpha", startAlpha, 1.0f)
        objectAnimator.interpolator = LinearInterpolator()
        if (smooth) {
            objectAnimator.duration = (duration * (1.0f - view.alpha) / 1.0f).toLong()
        } else {
            objectAnimator.duration = duration.toLong()
        }
        objectAnimator.start()
    }
    override fun onClick(p0: View?) {
        TODO("Not yet implemented")
    }


}