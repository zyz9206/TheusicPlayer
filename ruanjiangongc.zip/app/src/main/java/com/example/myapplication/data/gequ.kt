package com.example.myapplication.data
class response(val songs:List<gequ>,val code: Int)
class gequ(val name :String,val privilege:kj)
class kj(val id:Int)