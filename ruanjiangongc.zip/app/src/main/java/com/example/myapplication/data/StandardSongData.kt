package com.example.myapplication.data

import android.os.Parcel
import android.os.Parcelable

data class StandardSongData(var source: Int?, // 歌曲来源，网易，QQ，本地
                            var id: String?, // 歌曲 id

                            var name: String?, // 歌曲名称
                            var imageUrl: String?, // 图片 url
                            var artists: String?, //艺术家
)