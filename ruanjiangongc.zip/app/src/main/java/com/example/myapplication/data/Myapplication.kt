package com.example.myapplication.data

import android.app.Application
import android.content.Context
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class Myapplication :Application(){
    companion object{
        lateinit var context:Context
        val id="347231"
    }
    override fun onCreate() {
        super.onCreate()
        context=baseContext
    }
}