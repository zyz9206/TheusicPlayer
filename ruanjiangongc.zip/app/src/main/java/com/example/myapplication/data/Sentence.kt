package com.example.myapplication.data

data class Sentence(
    val hitokoto: String?,
    val author: String?,
    val source: String?
)
